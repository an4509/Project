
from django.contrib import admin
from board.models import Post, Posthr, Postps

admin.site.register(Post)

admin.site.register(Posthr)

admin.site.register(Postps)