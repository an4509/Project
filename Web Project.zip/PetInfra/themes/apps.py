from django.apps import AppConfig


class ThemesConfig(AppConfig):
    name = 'themes'
